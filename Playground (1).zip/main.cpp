#include <iostream>

using namespace std;


int main() {
     cout << "SPIDER MAN LOGO:   \n\n" << endl;
     cout << "      o  o    o  o        " << endl; 
	 cout << "      o o      o o        " << endl;
	 cout << "     o o        o o       " << endl;
	 cout << "     o o        o o       " << endl;
	 cout << "    oo o        o oo      " << endl; 
	 cout << "    oo o        o oo      " << endl;
	 cout << "    oo  oo oo oo  oo      " << endl;
	 cout << "    oooo oooooo oooo     _____ ____  _____ ____  _____ _____ " << endl;
	 cout << "    oo  o oooo o  oo     |     |   |   |   |   | |     |   |" << endl;
	 cout << "      oo oooooo oo       |____ |___|   |   |   | |__   |___|" << endl;
	 cout << "   o o  o oooo o  o o        | |       |   |   | |     |   \\" << endl;
	 cout << "   oo   o oooo o   oo    ____| |     __|__ |___| |____ |    \\" << endl;
	 cout << "   oo   o  oo  o   oo                 _____ " << endl;
	 cout << "   oo   o  oo  o   oo       |\\   /|  |     |  |\\    |            " << endl;
     cout << "   oo   o      o   oo       | \\ / |  |     |  | \\   |            " << endl;
	 cout << "   oo   o      o   oo       |  V  |  |_____|  |  \\  |            " << endl;
	 cout << "    o   o      o   o        |     |  |     |  |   \\ |            " << endl; 
	 cout << "    o   oo    oo   o        |     |  |     |  |    \\|            " << endl;
	 cout << "     o   o    o   o       " << endl;  
	 cout << "     o   o    o   o       " << endl;
	 cout << "      o  o    o  o        " << endl;
	 cout << "         o    o           " << endl;
	 cout << "          o  o            " << endl;

}
